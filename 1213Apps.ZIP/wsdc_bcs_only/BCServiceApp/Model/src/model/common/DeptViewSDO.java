package model.common;

public interface DeptViewSDO extends java.io.Serializable {

   public java.lang.Integer getDeptno();

   public void setDeptno(java.lang.Integer value);

   public java.lang.String getDname();

   public void setDname(java.lang.String value);

   public java.lang.String getLoc();

   public void setLoc(java.lang.String value);


}

